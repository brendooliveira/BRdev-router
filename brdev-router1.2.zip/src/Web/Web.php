<?php

namespace BRdev\Router\Web;

class Web
{

   public function home()
   {
        echo "Page Home";
   }

   public function about()
   {
        echo "Page About";
   }
}
