<?php

namespace BRdev\Router\App;

class App
{

   public function user($data)
   {
      echo "User id:" .$data["id"];
   }

}
